const express = require("express");
const cors = require("cors");
const path = require("path");
const dotenv = require("dotenv");

dotenv.config({ path: path.resolve(__dirname, "../.env"), quiet: true });
dotenv.config({ path: path.resolve(__dirname, "../.env.local"), override: true, quiet: true });

const routes = require("./routes/routes");
const { ensureAuditTable } = require("./controllers/auditController");
const { ensurePropertyTrashColumn } = require("./controllers/propertyController");
const { ensureUserTrashColumn } = require("./controllers/usersController");

const porta = process.env.PORT || 3500;
const app = express();

app.disable("x-powered-by");
app.set("trust proxy", 1);

ensureAuditTable().catch((err) => {
  console.error("Erro ao preparar auditoria:", err);
});
ensurePropertyTrashColumn().catch((err) => {
  console.error("Erro ao preparar lixeira:", err);
});
ensureUserTrashColumn().catch((err) => {
  console.error("Erro ao preparar lixeira de usuarios:", err);
});

const allowedOrigins = String(process.env.CORS_ORIGINS || "")
  .split(",")
  .map((origin) => origin.trim())
  .filter(Boolean);

app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "SAMEORIGIN");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  next();
});

app.use(cors({
  origin(origin, callback) {
    if (!origin || allowedOrigins.length === 0 || allowedOrigins.includes(origin)) {
      return callback(null, true);
    }

    return callback(new Error("Origem nao permitida pelo CORS"));
  }
}));
app.use(express.json({ limit: "1mb" }));

app.use(
  "/uploads",
  express.static(path.resolve(__dirname, "../../public_html/uploads"))
);

// 🔥 rotas api
app.use("/api", routes);

app.use((err, req, res, _next) => {
  if (err.message === "Origem nao permitida pelo CORS") {
    return res.status(403).json({ error: err.message });
  }

  if (err.code === "LIMIT_FILE_SIZE") {
    return res.status(400).json({ error: "Imagem acima do limite de 5MB" });
  }

  if (err.code === "LIMIT_FILE_COUNT") {
    return res.status(400).json({ error: "Limite de 20 imagens por envio" });
  }

  if (err.message === "Apenas imagens JPG, PNG, WEBP ou AVIF sao permitidas") {
    return res.status(400).json({ error: err.message });
  }

  console.error(err);
  return res.status(500).json({ error: "Erro interno do servidor" });
});

app.listen(porta, () => {
  console.log("Servidor rodando na porta " + porta);
});
